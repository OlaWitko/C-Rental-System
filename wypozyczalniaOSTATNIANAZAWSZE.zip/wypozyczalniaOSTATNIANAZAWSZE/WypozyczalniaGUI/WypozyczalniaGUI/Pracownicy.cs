﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WypozyczalniaGUI

{
    [Serializable]
    [XmlInclude(typeof(Osoba))]
    [XmlInclude(typeof(Pracownik))]
    public class Pracownicy 
    {

        
        //fields
        int liczbaPracownikow;
        public List<Osoba> listaPracownikow;

        public List<Osoba> ListaPracownikow { get => listaPracownikow; set => listaPracownikow = value; }

        public Pracownicy()
        {
            ListaPracownikow = new List<Osoba>();
        }

        //methods


        /// <summary>
        /// dodaje osobę do listy pracowników
        /// </summary>
        /// <param name="o"></param>
        public void Dodaj(Osoba o)
        {
            liczbaPracownikow++;
            ListaPracownikow.Add(o);
        }


        
       /// <summary>
       /// serializuje dane do pliku XML
       /// </summary>
       /// <param name="nazwa"></param>
        public void ZapiszXML(string nazwa)
        {
            XmlSerializer xs = new XmlSerializer(typeof(Pracownicy));
            using (StreamWriter sw = new StreamWriter(nazwa))
            {
                xs.Serialize(sw, this);
                sw.Close();
            }
        }

        /// <summary>
        /// odczytuje dane z pliku XML
        /// </summary>
        /// <param name="nazwa"></param>
        /// <returns></returns>
        public Pracownicy OdczytajXML(string nazwa)
        {
            Pracownicy wpracownicy;
            XmlSerializer xs = new XmlSerializer(typeof(Pracownicy));
            using (StreamReader sr = new StreamReader(nazwa))
            {
                wpracownicy = (Pracownicy)xs.Deserialize(sr);
                sr.Close();
            }
            return wpracownicy;
        }

        /// <summary>
        /// usuwa osobę o danym peselu z listy pracowników
        /// </summary>
        /// <param name="pesel"></param>
        public void Usun(string pesel)
        {
            foreach (Osoba o in ListaPracownikow)
            {
                if (o.Pesel == pesel)
                {
                    ListaPracownikow.Remove(o);
                    liczbaPracownikow--;
                }
                break;
            }
        }


        /// <summary>
        /// sortuje listę pracowników w kolejności alfabetycznej po nazwisku i imieniu
        /// </summary>
        public void Sortuj()
        {
            ListaPracownikow.Sort();
        }

        public int PodajIlosc()
        {
            return ListaPracownikow.Count();
        }


        /// <summary>
        /// wypisuje wszystkie dane osoby w liście pracowników
        /// </summary>
        /// <returns></returns>
        public string WypiszWszystkich()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Osoba o in ListaPracownikow)
            {
                sb.AppendLine(o.ToString());
            }
            return sb.ToString();
        }


        /// <summary>
        /// wyszukuje osobę o danym imieniu i nazwisku i dodaje do nowej listy
        /// </summary>
        /// <param name="imie"></param>
        /// <param name="nazwisko"></param>
        /// <returns></returns>
        public Pracownik Wyszukaj(string pesel)
        {
            Pracownik result = new Pracownik();
            foreach (Pracownik o in ListaPracownikow)
            {
                if (o.Pesel == pesel)
                {
                    result=o;
                }
            }
            return result;
        }

        
    }
}
