﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace WypozyczalniaGUI
{
    /// <summary>
    /// Logika interakcji dla klasy PanelPracownika.xaml
    /// </summary>
    public partial class PanelPracownika : Window
    {
        public static Pracownicy wpracownicy = new Pracownicy();

        public PanelPracownika()
        {
            InitializeComponent();
            if (File.Exists("PracownicyDane.xml"))
            {
                wpracownicy = wpracownicy.OdczytajXML("PracownicyDane.xml");
                LPracownicy.ItemsSource = new ObservableCollection<Osoba>(wpracownicy.ListaPracownikow);
            }
            

            


        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PanelPracownika.wpracownicy.Sortuj();
            PanelPracownika.wpracownicy.ZapiszXML("PracownicyDane.xml");
            wpracownicy = wpracownicy.OdczytajXML("PracownicyDane.xml");
            this.Close();
            PanelPracownika win1 = new PanelPracownika();
            win1.Show();
            MessageBox.Show($"Pracownicy zostali uporządkowani alfabetycznie nazwiskami.");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            FormularzPracownika win1 = new FormularzPracownika();
            win1.Show();
        }



        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            object item;
            item = LPracownicy.SelectedItem;
            if (LPracownicy.SelectedIndex != -1)
            {

                string[] pesel = item.ToString().Split(' ');
                wpracownicy.Usun(pesel[2]);
                wpracownicy.ZapiszXML("PracownicyDane.xml");
                LPracownicy.ItemsSource = new ObservableCollection<Osoba>(wpracownicy.ListaPracownikow);
                // PanelKlienta win1 = new PanelKlienta();
                //  win1.Show();
                MessageBox.Show("Usunąłeś pracownika");
        }
        }
    }
}
