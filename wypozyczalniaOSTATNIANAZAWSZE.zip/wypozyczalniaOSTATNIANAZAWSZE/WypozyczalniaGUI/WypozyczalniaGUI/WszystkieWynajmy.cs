﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WypozyczalniaGUI
{
    [Serializable]
    [XmlInclude(typeof(Wynajem))]
    [XmlInclude(typeof(Osobowe))]
    [XmlInclude(typeof(Pracownik))]
    [XmlInclude(typeof(Klient))]

    public class WszystkieWynajmy 
    {
        //fields
        static int liczbaWynajmow;
        public List<Wynajem> listaWynajmow;


        //constructors
        static WszystkieWynajmy()
        {
            liczbaWynajmow = 0;
        }

        public WszystkieWynajmy()
        {
            listaWynajmow = new List<Wynajem>();
        }

        //methods
        /// <summary>
        /// Funkcja dodająca nowy wynajem
        /// </summary>
        /// <param name="w"></param>
        public void Dodaj(Wynajem w)
        {
            liczbaWynajmow++;
            listaWynajmow.Add(w);
        }
        /// <summary>
        /// Funkcja usuwająca wynajem z listy wynajmów
        /// </summary>
        /// <param name="w"></param>
        public void Usun(Wynajem w)
        {
            liczbaWynajmow--;
            listaWynajmow.Remove(w);
        }

        /// <summary>
        /// Funkcja sortuje listę wynajmów po dacie początku wynajmu 
        /// </summary>
        public void Sortuj()
        {
            listaWynajmow.Sort();
        }
        /// <summary>
        /// Funkcja pokazuje ostatni wynajem
        /// </summary>
        /// <returns></returns>
        public Wynajem Ostatnia()
        {
            return listaWynajmow.Last();
        }
        /// <summary>
        /// Funkcja podaje ilość wynajmów
        /// </summary>
        /// <returns></returns>
        public int PodajIlosc()
        {
            return listaWynajmow.Count();
        }
        /// <summary>
        /// Funkcja podaje ilość wynajmów utworzonych dzisiaj
        /// </summary>
        /// <returns></returns>
        public int PodajIloscDzisiaj()
        {
            int iloscDzisiaj = 0;
            foreach (Wynajem w in listaWynajmow)
            {
                if (w.DataUtworzenia.Date == DateTime.Now.Date)
                {
                    iloscDzisiaj++;
                }
            }
            return iloscDzisiaj;
        }
        /// <summary>
        /// Funkcja podaje wynajmy utworzone dzisiaj
        /// </summary>
        /// <returns></returns>
        public List<Wynajem> PodajUtworzoneDzisiaj()
        {
            List<Wynajem> result = new List<Wynajem>();
            foreach (Wynajem w in listaWynajmow)
            {
                if (w.DataUtworzenia == DateTime.Now.Date)
                {
                    result.Add(w);
                }
            }
            if (!result.Any())
                throw new EmptyListException($"Lista wynajmów nie zawiera żadnego wynajmu utworzonego dzisiaj ({DateTime.Now.Date})");
            return result;
        }
        /// <summary>
        /// Funkcja sortuje wynajmy po dacie utworzenia
        /// </summary>
        /// <returns></returns>
        public List<Wynajem> SortujPoUtworzenie()
        {
            List<Wynajem> result = listaWynajmow;
            result.OrderBy((Wynajem arg) => arg.DataUtworzenia).ToList();
            if (!result.Any())
                throw new EmptyListException($"Lista wynajmów nie zawiera żadnego wynajmu do posegregowania");
            return result;
        }
        /// <summary>
        /// Funkcja wypisuje trwające wynajmy
        /// </summary>
        /// <returns></returns>
        public List<Wynajem> WypiszTrwajace()
        {
            List<Wynajem> result = new List<Wynajem>();
            foreach (Wynajem w in listaWynajmow)
            {
                if (w.PoczatekWynajmu < DateTime.Now && w.KoniecWynajmu > DateTime.Now)
                {
                    result.Add(w);
                }
            }
            if (!result.Any())
                throw new EmptyListException($"Lista wynajmów nie zawiera żadnego wynajmu utworzonego dzisiaj ({DateTime.Now.Date})");
            return result;
        }
        /// <summary>
        /// Funkcja wypisuje wszystkie wynajmy
        /// </summary>
        /// <returns></returns>
        public List<Wynajem> WypiszWszystkie()
        {
            return listaWynajmow;
        }
        /// <summary>
        /// Funkcja serializuje dane do pliku XML
        /// </summary>
        /// <param name="nazwa"></param>
        public void ZapiszXML(string nazwa)
        {
            XmlSerializer xs = new XmlSerializer(typeof(WszystkieWynajmy));
            using (StreamWriter sw = new StreamWriter(nazwa))
            {
                xs.Serialize(sw, this);
                sw.Close();
            }
        }
        /// <summary>
        /// Funkcja odczytuje dane z pliku XML
        /// </summary>
        /// <param name="nazwa"></param>
        /// <returns></returns>
        public WszystkieWynajmy OdczytajXML(string nazwa)
        {
            WszystkieWynajmy wwynajmy;
            XmlSerializer xs = new XmlSerializer(typeof(WszystkieWynajmy));
            using (StreamReader sr = new StreamReader(nazwa))
            {
                wwynajmy = (WszystkieWynajmy)xs.Deserialize(sr);
                sr.Close();
            }
            return wwynajmy;
        }
    }
}
