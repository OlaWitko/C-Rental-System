﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WypozyczalniaGUI
{
    /// <summary>
    /// Logika interakcji dla klasy FormularzWypozyczenia.xaml
    /// </summary>
    public partial class FormularzWypozyczenia : Window
    {
        Pojazdy wpojazdy = new Pojazdy();
        WszyscyKlienci wklienci = new WszyscyKlienci();
        Pracownicy wpracownicy = new Pracownicy();
        WszystkieWynajmy wwynajmy = new WszystkieWynajmy();

        public FormularzWypozyczenia()
        {
            InitializeComponent();
            if (File.Exists("PojazdyDane.xml"))
            {
                wpojazdy = wpojazdy.OdczytajXML("PojazdyDane.xml");
                foreach (Samochod s in wpojazdy.listaPojazdow)
                {
                    CBSamochod.Items.Add(s.ToString());
                }
            }
            if (File.Exists("KlienciDane.xml"))
            {
                wklienci = wklienci.OdczytajXML("KlienciDane.xml");
                foreach (Klient k in wklienci.ListaKlientow)
                {
                    CBKlient.Items.Add(k.ToString());
                }
            }
            if (File.Exists("PracownicyDane.xml"))
            {
                wpracownicy = wpracownicy.OdczytajXML("PracownicyDane.xml");
                foreach (Pracownik p in wpracownicy.listaPracownikow)
                {
                    CBPracownik.Items.Add(p.ToString());
                }
            }



        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string sam = this.CBSamochod.Text;
            string kl = this.CBKlient.Text;
            string pr = this.CBPracownik.Text;

            string nrrej = sam.Split(' ')[3].Substring(0, 7);
            string klpes = kl.Split(' ')[2];
            string prpes = pr.Split(' ')[2];

            

            Klient k = wklienci.Wyszukaj(klpes);
            Pracownik p = wpracownicy.Wyszukaj(prpes);
            Osobowe o = wpojazdy.Wyszukaj(nrrej);

            MessageBox.Show($"{o.ToString()}, {k.ToString()}, {p.ToString()}");

            Wynajem w = new Wynajem(CPoczatek.SelectedDate.ToString(), CKoniec.SelectedDate.ToString(), o, p, k);
            wwynajmy.Dodaj(w);
            wwynajmy.ZapiszXML("WynajmyDane.xml");

            MessageBox.Show($"Zapisano wynajem {w.ToString()}");


        }

    }
}
