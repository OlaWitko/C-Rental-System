﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WypozyczalniaGUI
{
    [Serializable]
    [XmlInclude(typeof(Klient))]
    public class WszyscyKlienci 
    {
        //fields
        int liczbaKlientow=1;
        List<Klient> listaKlientow;

        public int LiczbaKlientow { get => liczbaKlientow; set => liczbaKlientow = value; }
        public List<Klient> ListaKlientow { get => listaKlientow; set => listaKlientow = value; }

        public WszyscyKlienci()
        {
            ListaKlientow = new List<Klient>();
        }
        //methods

        /// <summary>
        /// funkcja dodaje nowego klienta do listy
        /// </summary>
        /// <param name="o"></param>
        public void Dodaj(Klient o)
        {
            LiczbaKlientow++;
            ListaKlientow.Add(o);
        }
        /// <summary>
        /// funkcja usuwa klienta z listy
        /// </summary>
        /// <param name="pesel"></param>
        public void Usun(string pesel)
        {
            foreach (Klient o in ListaKlientow)
            {
                if (o.Pesel == pesel)
                {
                    ListaKlientow.Remove(o);
                    LiczbaKlientow--;
                    break;
                }
                
            }
        }
        /// <summary>
        /// funkcja podaje aktualną liczbę klientów
        /// </summary>
        /// <returns></returns>
        public int PodajIlosc()
        {
            return ListaKlientow.Count();
        }

        /// <summary>
        /// Funkcja sortuje klientów po nazwisku i imieniu
        /// </summary>
        public void Sortuj()
        {
            listaKlientow.Sort();
        }

        public string WypiszWszystkich()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Klient o in ListaKlientow)
            {
                sb.AppendLine(o.ToString());
            }
            return sb.ToString();
        }
        /// <summary>
        /// Funkcja wyszukuje klienta po imieniu i nazwisku
        /// </summary>
        /// <param name="imie"></param>
        /// <param name="nazwisko"></param>
        /// <returns></returns>
        public Klient Wyszukaj(string pesel)
        {
            Klient result = new Klient();
            foreach (Klient o in ListaKlientow)
            {
                if (o.Pesel == pesel)
                {
                    result=o;
                }
            }
            return result;
        }
        /// <summary>
        /// Funkcja serializuje dane do pliku XML
        /// </summary>
        /// <param name="nazwa"></param>
        public void ZapiszXML(string nazwa)
        {
            XmlSerializer xs = new XmlSerializer(typeof(WszyscyKlienci));
            using (StreamWriter sw = new StreamWriter(nazwa))
            {
                xs.Serialize(sw, this);
                sw.Close();
            }
        }
        /// <summary>
        /// Funkcja odczytuje dane z pliku XML
        /// </summary>
        /// <param name="nazwa"></param>
        /// <returns></returns>
        public WszyscyKlienci OdczytajXML(string nazwa)
        {
            WszyscyKlienci wklienci;
            XmlSerializer xs = new XmlSerializer(typeof(WszyscyKlienci));
            using(StreamReader sr = new StreamReader(nazwa))
            {
                wklienci = (WszyscyKlienci)xs.Deserialize(sr);
                sr.Close();
            }
            return wklienci;
        }
       

    }
}
