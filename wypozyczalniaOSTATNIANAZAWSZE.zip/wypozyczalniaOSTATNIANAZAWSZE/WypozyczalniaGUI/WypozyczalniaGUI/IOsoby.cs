﻿using System;
using System.Collections.Generic;

namespace WypozyczalniaGUI
{
    interface IOsoby
    {
        void Dodaj(Osoba o);
        void Usun(string pesel);
        List<Osoba> Wyszukaj(string imie, string nazwisko);
        string WypiszWszystkich();
        int PodajIlosc();
    }
}
