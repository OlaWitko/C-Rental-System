﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WypozyczalniaGUI
{
    [Serializable]
    [XmlInclude(typeof(Samochod))]
    public class Pojazdy 
    {
        static int liczbaSamochodow;
        public List<Osobowe> listaPojazdow;

        //constructors
        static Pojazdy()
        {
            liczbaSamochodow = 0;
        }

        public Pojazdy()
        {
            listaPojazdow = new List<Osobowe>();
        }

        //methods

        /// <summary>
        /// dodaje samochód do listy pojazdów
        /// </summary>
        /// <param name="s"></param>
        public void Dodaj(Osobowe s)
        {
            liczbaSamochodow++;
            listaPojazdow.Add(s);
        }


        /// <summary>
        /// sortuje listę pojazdów po modelu i marce
        /// </summary>
        public void Sortuj()
        {
            listaPojazdow.Sort();
        }



        /// <summary>
        /// usuwa samochód z listy pojazdów
        /// </summary>
        /// <param name="s"></param>
        public void Usun(string nrrej)
        {
            liczbaSamochodow--;
            foreach(Osobowe o in listaPojazdow)
            {
                if(o.NrRejestracyjny == nrrej)
                {
                    listaPojazdow.Remove(o);
                    break;
                }
                
            }
        }


        /// <summary>
        /// wyszukuje samochód o danym id, jeżeli istnieje
        /// </summary>
        /// <param name="idSamochodu"></param>
        /// <returns></returns>
        public Samochod Wyszkuj(int idSamochodu)
        {
            foreach (Samochod s in listaPojazdow)
            {
                if (s.IdSamochodu == idSamochodu)
                {
                    return s;
                }
            }
            //tu kod teoretycznie nie powinien dojść jeżeli mamy samochód o podanym ID, dlatego wyjątek jest bez if/try_catch
            new EmptyListException($"W liście samochodów nie istnieje pojazd o IDSamochodu: {idSamochodu}!");
            return null;
        }


        /// <summary>
        /// wyszukuje samochód o podanej marce i dodaje do listy lub wyrzuca wyjątek
        /// </summary>
        /// <param name="marka"></param>
        /// <returns></returns>
        public Osobowe Wyszukaj(string nrrejestracyjny)
        {
            Osobowe res = new Osobowe();
            foreach (Osobowe s in listaPojazdow)
            {
                if (s.NrRejestracyjny == nrrejestracyjny)
                {
                    res = s;
                }
            }
            return res;
        }



        /// <summary>
        /// wyszukuje samochód o podanym przebiegu i dodaje do listy lub wyrzuca wyjątek
        /// </summary>
        /// <param name="przebieg"></param>
        /// <returns></returns>
        public List<Samochod> Wyszukaj(float przebieg)
        {
            List<Samochod> result_list = new List<Samochod>();
            foreach (Samochod s in listaPojazdow)
            {
                if (s.Przebieg < przebieg)
                {
                    result_list.Add(s);
                }
            }
            if (!result_list.Any())
                new EmptyListException($"W liście samochodów nie istnieje pojazd, którego przebieg jest mniejszy niż: {przebieg}!");
            return result_list;
        }



        /// <summary>
        /// wyszukuje samochód o podanej ilości miejsc i dodaje do listy lub wyrzuca wyjątek
        /// </summary>
        /// <param name="iloscMiejsc"></param>
        /// <returns></returns>
        public List<Samochod> Wyszukaj(int iloscMiejsc)
        {
            List<Samochod> result_list = new List<Samochod>();
            foreach (Samochod s in listaPojazdow)
            {
                if (s.IloscMiejsc == iloscMiejsc)
                {
                    result_list.Add(s);
                }
            }
            if (!result_list.Any())
                new EmptyListException($"W liście samochodów nie istnieje pojazd, który posiada wybraną ilość miejsc: {iloscMiejsc}!");
            return result_list;
        }


        /// <summary>
        /// wyszukuje samochód o podanej skrzyni biegów i dodaje do listy lub wyrzuca wyjątek
        /// </summary>
        /// <param name="skrzynia"></param>
        /// <returns></returns>
        public List<Samochod> Wyszukaj(EnumSkrzyniaBiegow skrzynia)
        {
            List<Samochod> result_list = new List<Samochod>();
            foreach (Samochod s in listaPojazdow)
            {
                if (s.Skrzynia == skrzynia)
                {
                    result_list.Add(s);
                }
            }
            if (!result_list.Any())
                new EmptyListException($"W liście samochodów nie istnieje pojazd ze skrzynią: {skrzynia}!");
            return result_list;
        }


        /// <summary>
        /// wyszukuje samochód o podanym koszcie dziennym i dodaje do listy lub wyrzuca wyjątek
        /// </summary>
        /// <param name="kosztDzienny"></param>
        /// <returns></returns>
        public List<Samochod> WyszukajKosztDz(float kosztDzienny)
        {
            List<Samochod> result_list = new List<Samochod>();
            foreach (Samochod s in listaPojazdow)
            {
                if (s.KosztZaDzien < kosztDzienny)
                {
                    result_list.Add(s);
                }
            }
            if (!result_list.Any())
                new EmptyListException($"W liście samochodów nie istnieje pojazd, którego koszt dzienny jest mniejszy niż: {kosztDzienny}!");
            return result_list;
        }



        /// <summary>
        /// wyszukuje samochód o podanym roku produkcji i dodaje do listy lub wyrzuca wyjątek
        /// </summary>
        /// <param name="rokProdukcji"></param>
        /// <returns></returns>
        public List<Samochod> WyszukajRokPr(int rokProdukcji)
        {
            List<Samochod> result_list = new List<Samochod>();
            foreach (Samochod s in listaPojazdow)
            {
                if (s.RokProdukcji < rokProdukcji)
                {
                    result_list.Add(s);
                }
            }
            if (!result_list.Any())
                new EmptyListException($"W liście samochodów nie istnieje pojazd, którego rok produkcji jest mniejszy niż: {rokProdukcji}!");
            return result_list;
        }
       
        /// <summary>
        /// funkcja serializuje dane do pliku XML
        /// </summary>
        /// <param name="nazwa"></param>
        public void ZapiszXML(string nazwa)
        {
            XmlSerializer xs = new XmlSerializer(typeof(Pojazdy));
            using (StreamWriter sw = new StreamWriter(nazwa))
            {
                xs.Serialize(sw, this);
                sw.Close();
            }
        }

        /// <summary>
        /// funkcja odczytuje dane z pliku XML
        /// </summary>
        /// <param name="nazwa"></param>
        /// <returns></returns>
        public Pojazdy OdczytajXML(string nazwa)
        {
            Pojazdy wpojazdy;
            XmlSerializer xs = new XmlSerializer(typeof(Pojazdy));
            using (StreamReader sr = new StreamReader(nazwa))
            {
                wpojazdy = (Pojazdy)xs.Deserialize(sr);
                sr.Close();
            }
            return wpojazdy;
        }
    }
    class EmptyListException : Exception
    {
        public EmptyListException() : base() { }
        public EmptyListException(string message) : base(message) { }
    }
}
