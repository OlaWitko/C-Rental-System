﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WypozyczalniaGUI
{
    /// <summary>
    /// Logika interakcji dla klasy FormularzPracownika.xaml
    /// </summary>
    public partial class FormularzPracownika : Window
    {
        public FormularzPracownika()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            EnumPlcie plec = EnumPlcie.K;
            if (RBKobieta.IsChecked == true && RBMezczyzna.IsChecked == false)
            {
                plec = EnumPlcie.K;
            }
            else if (RBKobieta.IsChecked == false && RBMezczyzna.IsChecked == true)
            {
                plec = EnumPlcie.M;
            }
            Pracownik p = new Pracownik(TImie.Text, TNazwisko.Text, TPesel.Text, int.Parse(TNrTel.Text), plec, CDataUr.SelectedDate.ToString(), int.Parse(TIDPrac.Text), TPozycja.Text, TMiasto.Text, int.Parse(TKod.Text), TUlica.Text, TNrDomu.Text);
            PanelPracownika.wpracownicy.Dodaj(p);
            PanelPracownika.wpracownicy.ZapiszXML("PracownicyDane.xml");
            MessageBox.Show($"Dodano pracownika {TImie.Text} {TNazwisko.Text} {TPesel.Text}");
        }
    }
}
