﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace WypozyczalniaGUI
{
    /// <summary>
    /// Logika interakcji dla klasy PanelPojazdu.xaml
    /// </summary>
    public partial class PanelPojazdu : Window
    {
        public static Pojazdy wpojazdy = new Pojazdy();
        public PanelPojazdu()
        {
            if (File.Exists("PojazdyDane.xml"))
            {
                wpojazdy = wpojazdy.OdczytajXML("PojazdyDane.xml");
            }
            InitializeComponent();
            foreach(Samochod s in wpojazdy.listaPojazdow)
            {
                LPojazdy.Items.Add(s.ToString());
            }
        }

        private void BDodaj_Click(object sender, RoutedEventArgs e)
        {
            FormularzPojazdu win1 = new FormularzPojazdu();
            win1.Show();
        }

        private void BSortuj_Click(object sender, RoutedEventArgs e)
        {
            PanelPojazdu.wpojazdy.Sortuj();
            PanelPojazdu.wpojazdy.ZapiszXML("PojazdyDane.xml");
            wpojazdy = wpojazdy.OdczytajXML("PojazdyDane.xml");
            this.Close();
            PanelPojazdu win1 = new PanelPojazdu();
            win1.Show();
            MessageBox.Show($"Pojazdy zostały uporządkowane alfabetycznie.");
        }

        private void BUsun_Click(object sender, RoutedEventArgs e)
        {
            object item;
            item = LPojazdy.SelectedItem;
            if (LPojazdy.SelectedIndex != -1)
            {

                string[] nrrej = item.ToString().Split(' ');
                wpojazdy.Usun(nrrej[3].Substring(0, 7));

                wpojazdy.ZapiszXML("PojazdyDane.xml");
                LPojazdy.Items.Clear();
                foreach(Osobowe o in wpojazdy.listaPojazdow)
                {
                    LPojazdy.Items.Add(o.ToString());
                }
                //LPojazdy.ItemsSource = new ObservableCollection<Osobowe>(wpojazdy.listaPojazdow);
                // PanelKlienta win1 = new PanelKlienta();
                //  win1.Show();
                MessageBox.Show("Usunąłeś pojazd");

            }

        }
    }
}
