﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WypozyczalniaGUI
{

    /// <summary>
    /// Logika interakcji dla klasy FormularzKlienta.xaml
    /// </summary>
    public partial class FormularzKlienta : Window
    {
        static public WszyscyKlienci klienci = new WszyscyKlienci();

        public FormularzKlienta()
        {
            InitializeComponent();
        }

       

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            EnumPlcie plec = EnumPlcie.K;
            if (RKobieta.IsChecked == true && RMezczyzna.IsChecked == false)
            {
                plec = EnumPlcie.K;
            }
            else if (RKobieta.IsChecked == false && RMezczyzna.IsChecked == true)
            {
                plec = EnumPlcie.M;
            }

            Klient k = new Klient(TImie.Text, TNazwisko.Text, TPesel.Text, int.Parse(TNrTel.Text), plec, CDataUr.SelectedDate.ToString(), TEmail.Text, DateTime.Now.ToString());
            PanelKlienta.wklienci.Dodaj(k);
            PanelKlienta.wklienci.ZapiszXML("KlienciDane.xml");
            MessageBox.Show($"Dodano klienta {TImie.Text}, {TNazwisko.Text}, {TPesel.Text}, {TNrTel.Text}, {TEmail.Text}");
            
        }
    }
}
