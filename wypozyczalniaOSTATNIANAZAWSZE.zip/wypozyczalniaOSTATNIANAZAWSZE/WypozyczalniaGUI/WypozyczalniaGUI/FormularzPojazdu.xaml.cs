﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WypozyczalniaGUI
{
    /// <summary>
    /// Logika interakcji dla klasy FormularzPojazdu.xaml
    /// </summary>
    public partial class FormularzPojazdu : Window
    {
        public FormularzPojazdu()
        {
            InitializeComponent();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            EnumPaliwa paliwo = EnumPaliwa.benzyna;
            if(RBBenzyna.IsChecked == true && RBDiesel.IsChecked == false)
            {
                paliwo = EnumPaliwa.benzyna;
            }else if(RBBenzyna.IsChecked == false && RBDiesel.IsChecked == true)
            {
                paliwo = EnumPaliwa.diesel;
            }

            EnumSkrzyniaBiegow skrzynia = EnumSkrzyniaBiegow.manualna;
            if(RBManual.IsChecked == true && RBAutomat.IsChecked == false)
            {
                skrzynia = EnumSkrzyniaBiegow.manualna;
            }else if(RBManual.IsChecked == false && RBAutomat.IsChecked == true)
            {
                skrzynia = EnumSkrzyniaBiegow.automatyczna;
            }
            Osobowe o = new Osobowe(TMarka.Text, TModel.Text, TNrRej.Text, float.Parse(TPrzebieg.Text), int.Parse(TIloscMsc.Text), int.Parse(TRokPr.Text), int.Parse(TPojemnoscBag.Text), double.Parse(TSpalanie.Text), float.Parse(TKoszt.Text), paliwo, skrzynia);
            PanelPojazdu.wpojazdy.Dodaj(o);
            PanelPojazdu.wpojazdy.ZapiszXML("PojazdyDane.xml");
            MessageBox.Show($"Dodano pojazd {TMarka.Text}, {TModel.Text}, {TNrRej.Text}");
        }
    }
}
