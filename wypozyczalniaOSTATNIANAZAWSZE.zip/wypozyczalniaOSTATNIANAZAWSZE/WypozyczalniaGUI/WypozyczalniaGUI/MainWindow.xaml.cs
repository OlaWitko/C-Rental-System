﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WypozyczalniaGUI
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        

        public MainWindow()
        {

        }

        private void BPracownicy_Click(object sender, RoutedEventArgs e)
        {
            PanelPracownika win1 = new PanelPracownika();
            win1.Show();
        }

        private void BKlienci_Click(object sender, RoutedEventArgs e)
        {
            PanelKlienta win1 = new PanelKlienta();
            win1.Show();
        }

        private void BPojazdy_Click(object sender, RoutedEventArgs e)
        {
            PanelPojazdu win1 = new PanelPojazdu();
            win1.Show();
        }

        private void BWypozyczenia_Click(object sender, RoutedEventArgs e)
        {
            PanelWypozyczenia win1 = new PanelWypozyczenia();
            win1.Show();
        }
    }
}
