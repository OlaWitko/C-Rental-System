﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WypozyczalniaGUI
{
    [Serializable]
    public class Wynajem: IComparable<Wynajem>
    {
        //fields
        static int numerWynajmu = 1;
        DateTime poczatekWynajmu;
        DateTime koniecWynajmu;
        DateTime dataUtworzenia;
        Samochod samochod;
        Pracownik pracownik;
        Klient klient;


        //accessors
        public static int NumerWynajmu { get => numerWynajmu; set => numerWynajmu = value; }
        public DateTime PoczatekWynajmu { get => poczatekWynajmu; set => poczatekWynajmu = value; }
        public DateTime KoniecWynajmu { get => koniecWynajmu; set => koniecWynajmu = value; }
        public DateTime DataUtworzenia { get => dataUtworzenia; set => dataUtworzenia = value; }
        public Samochod Samochod { get => samochod; set => samochod = value; }
        public Pracownik Pracownik { get => pracownik; set => pracownik = value; }
        public Klient Klient { get => klient; set => klient = value; }


        //construcors
        public Wynajem()
        {
            numerWynajmu++;
        }

        public Wynajem(string poczatekWynajmu, string koniecWynajmu, Samochod samochod, Pracownik pracownik, Klient klient)
            : this()
        {
            this.poczatekWynajmu = DateTime.Parse(poczatekWynajmu);
            this.koniecWynajmu = DateTime.Parse(koniecWynajmu);
            this.samochod = samochod;
            this.pracownik = pracownik;
            this.klient = klient;
        }

        //methods
        
        /// <summary>
        /// Funkcja sprawdza czy podana data początku wynajmu nie jest z przeszłości
        /// </summary>
        public void CzyStaraData()
        {
            if (DateTime.Now > poczatekWynajmu || DateTime.Now > koniecWynajmu)
            {
                throw new PastDateException("Wybrana data początku/końca wynajmu jest z przeszłości! Wybierz poprawną datę i spróbuj pownownie.");
            }
        }
        public override string ToString()
        {
            return (poczatekWynajmu + " " + koniecWynajmu + " " + samochod + " " + klient + " " + pracownik);
        }
        /// <summary>
        /// Funkcja sprawdza czy początek wynajmu jest wcześniej niż koniec wynajmu
        /// </summary>
        public void CzyPoczatekGTKonie()
        {
            if (poczatekWynajmu > koniecWynajmu)
            {
                throw new WrongReturnDateException("Data konca wynajmu nie może poprzedzać daty rozpoczęcia! Wybierz poprawną datę i spróbuj pownownie.");
            }
        }
        /// <summary>
        /// Funkcja porównuje wynajmy względem początku wynajmu
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public int CompareTo(Wynajem other)
        {
            return this.PoczatekWynajmu.CompareTo(other.PoczatekWynajmu);
        }

    }
}

