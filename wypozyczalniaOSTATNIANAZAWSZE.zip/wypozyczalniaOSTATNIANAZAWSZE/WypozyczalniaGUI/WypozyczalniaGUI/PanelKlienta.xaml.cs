﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace WypozyczalniaGUI
{
    /// <summary>
    /// Logika interakcji dla klasy PanelKlienta.xaml
    /// </summary>
    public partial class PanelKlienta : Window
    {
        public static WszyscyKlienci wklienci = new WszyscyKlienci();

        public PanelKlienta()
        {
            if (File.Exists("KlienciDane.xml"))
            {
                wklienci = wklienci.OdczytajXML("KlienciDane.xml");
            }
               
            InitializeComponent();
            LKlient.ItemsSource = new ObservableCollection<Klient>(wklienci.ListaKlientow);

        }

        private void BDodaj_Click(object sender, RoutedEventArgs e)
        {
            FormularzKlienta win1 = new FormularzKlienta();
            win1.Show();
        }


        private void BUsun_Click(object sender, RoutedEventArgs e)
        {
            object item;
            item = LKlient.SelectedItem;
            if (LKlient.SelectedIndex != -1)
            {
          
                string[] pesel = item.ToString().Split(' ');
                wklienci.Usun(pesel[2]);

                wklienci.ZapiszXML("KlienciDane.xml");
                LKlient.ItemsSource = new ObservableCollection<Klient>(wklienci.ListaKlientow);
                // PanelKlienta win1 = new PanelKlienta();
                //  win1.Show();
                MessageBox.Show("Usunąłeś klienta");

            }
            
        }


        private void BSortuj_Click(object sender, RoutedEventArgs e)
        {
            PanelKlienta.wklienci.Sortuj();
            PanelKlienta.wklienci.ZapiszXML("KlienciDane.xml");
            wklienci = wklienci.OdczytajXML("KlienciDane.xml");
            this.Close();
            PanelKlienta win1 = new PanelKlienta();
            win1.Show();
            MessageBox.Show($"Klienci zostali uporządkowani alfabetycznie nazwiskami.");
        }
    }
}
