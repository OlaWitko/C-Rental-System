﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WypozyczalniaGUI
{
    [Serializable]
    class WszystkieRezerwacje 
    {
        //fields
        static int liczbaRezerwacji;
        List<Rezerwacja> listaRezerwacji;

        //constructors
        static WszystkieRezerwacje()
        {
            liczbaRezerwacji = 0;
        }

        public WszystkieRezerwacje()
        {
            listaRezerwacji = new List<Rezerwacja>();
        }

        //methods

        /// <summary>
        /// Funkcja dodaje nową rezerwacje
        /// </summary>
        /// <param name="r"></param>
        public void Dodaj(Rezerwacja r)
        {
            liczbaRezerwacji++;
            listaRezerwacji.Add(r);
        }
        /// <summary>
        /// Funkcja usuwa rezerwacje z listy rezerwacji
        /// </summary>
        /// <param name="r"></param>

        public void Usun(Rezerwacja r)
        {
            liczbaRezerwacji--;
            listaRezerwacji.Remove(r);
        }

        /// <summary>
        /// Funkcja zwraca ostatnią rezerwacje, jeżeli taka istnieje
        /// </summary>
        /// <returns></returns>
        public Rezerwacja Ostatnia()
        {
            if (!listaRezerwacji.Any())
                throw new EmptyListException("Lista rezerwacji nie zawiera żadnej rezerwacji!");
            else
                return listaRezerwacji.Last();
        }
        /// <summary>
        /// Funkcja podaje ilość wszystkich rezerwacji
        /// </summary>
        /// <returns></returns>

        public int PodajIlosc()
        {
            return listaRezerwacji.Count();
        }
        /// <summary>
        /// Funkcja podaje ilość dzisiejszych rezerwacji
        /// </summary>
        /// <returns></returns>
        public int PodajIloscDzisiaj()
        {
            int iloscDzis = 0;
            foreach (Rezerwacja r in listaRezerwacji)
            {
                if (r.DataUtworzenia.Date == DateTime.Now.Date)
                {
                    iloscDzis++;
                }
            }
            return iloscDzis;
        }
        /// <summary>
        /// wyświetla listę rezerwacji utworzonych dzisiaj
        /// </summary>
        /// <returns></returns>
        public List<Rezerwacja> PodajUtworzoneDzisiaj()
        {
            List<Rezerwacja> result = new List<Rezerwacja>();
            foreach (Rezerwacja r in listaRezerwacji)
            {
                if (r.DataUtworzenia.Date == DateTime.Now.Date)
                {
                    result.Add(r);
                }
            }
            if (!result.Any())
                throw new EmptyListException($"Lista rezerwacji, nie zawiera żadnych rezerwacji utworzonych dzisiaj {DateTime.Now.Date}");

            return result;
        }
        /// <summary>
        /// Funkcja wyświetla rezerwacje, które są trwające
        /// </summary>
        /// <returns></returns>
        public List<Rezerwacja> WypiszTrwajace()
        {
            List<Rezerwacja> result = new List<Rezerwacja>();
            foreach (Rezerwacja r in listaRezerwacji)
            {
                if (r.PoczatekRezerwacji < DateTime.Now && r.KoniecRezerwacji > DateTime.Now)
                {
                    result.Add(r);
                }
            }
            if (!result.Any())
                throw new EmptyListException($"Lista rezerwacji, nie zawiera żadnych aktualnie trwających rezerwacji");

            return result;
        }
        /// <summary>
        /// Funkcja wyświetla wszystkie rezerwacje
        /// </summary>
        /// <returns></returns>
        public List<Rezerwacja> WypiszWszystkie()
        {
            return listaRezerwacji;    //chyba najgłupsza z wszystkich
        }
        /// <summary>
        /// Funkcja sotująca rezerwacje po dacie utworzenia
        /// </summary>
        /// <returns></returns>
        public List<Rezerwacja> SortujPoUtworzenie()
        {
            List<Rezerwacja> result = listaRezerwacji;
            result = listaRezerwacji.OrderBy((Rezerwacja arg) => arg.DataUtworzenia).ToList();  //powinno działać ale nie wiadomo
            if (!result.Any())
                throw new EmptyListException($"Lista rezerwacji nie zawiera żadnego wynajmu do posegregowania");
            return result;
        }
    }
}

